#!/bin/bash
# Git auto-push script for Seima Sumu V2

echo "📦 Adding all files..."
git add .

echo "📝 Committing changes..."
git commit -m 'Updated Seima Sumu V2 with new features'

echo "🚀 Pushing to GitHub..."
git push -u origin main

echo "✅ Done!"
