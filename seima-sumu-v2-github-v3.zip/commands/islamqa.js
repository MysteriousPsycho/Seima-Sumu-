const axios = require("axios");
module.exports = {
    name: "islamqa",
    async execute(api, message, args) {
        const question = args.join(" ");
        if (!question) return api.sendMessage("❓ Please ask an Islamic question.", message.threadID);

        try {
            const response = await axios.get(`https://api.aladhan.com/v1/asmaAlHusna/1`);
            const result = response.data.data;
            const reply = `🕌 *Islamic Q&A*

Here's one of the names of Allah:

**${result.name}** — ${result.en.meaning}`;
            api.sendMessage(reply, message.threadID);
        } catch (err) {
            api.sendMessage("⚠️ Could not fetch Islamic content.", message.threadID);
        }
    }
};
