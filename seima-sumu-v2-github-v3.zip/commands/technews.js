module.exports = {
    name: "technews",
    execute(api, message) {
        api.sendMessage("📰 Tech news feature coming soon!", message.threadID);
    }
};
