const sessions = {};

module.exports = {
    name: "guess",
    execute(api, message, args) {
        const threadID = message.threadID;

        if (!sessions[threadID]) {
            sessions[threadID] = Math.floor(Math.random() * 10) + 1;
            return api.sendMessage("🎯 I'm thinking of a number between 1 and 10. Guess it!", threadID);
        }

        const guess = parseInt(args[0]);
        if (guess === sessions[threadID]) {
            api.sendMessage("🎉 Correct! You guessed it!", threadID);
            delete sessions[threadID];
        } else {
            api.sendMessage("❌ Nope! Try again.", threadID);
        }
    }
};
