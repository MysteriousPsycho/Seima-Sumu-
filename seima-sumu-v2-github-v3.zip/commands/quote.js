const axios = require("axios");
module.exports = {
    name: "quote",
    async execute(api, message) {
        try {
            const response = await axios.get("https://api.quotable.io/random");
            const quote = response.data;
            api.sendMessage(`💬 "${quote.content}"
— ${quote.author}`, message.threadID);
        } catch {
            api.sendMessage("⚠️ Couldn't fetch quote.", message.threadID);
        }
    }
};
